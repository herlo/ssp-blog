<?php
/*
Plugin Name: Email 5 People
Plugin URI: http://sexysexypenguins.com/wp-content/uploads/2008/12/email_5_people.zip
Description: Email 5 or more People
Version: 0.2
Author: Clint Savage <herlo1@gmail.com>
Author URI: http://sexysexypenguins.com
*/

function email_5_people($post_ID)  {

	// this gets the who we're sending from, we only take the first value
	$mail_from = 'bob@example.com';

	// this gets the 5 email addresses
	$to = get_post_custom_values('Email_To', $post_ID);
	if (!empty($to))
	{
		$mail_to = implode(",", $to);
	
		// this is the actual post info, subject and post_data
		$post_data = get_postdata($post_ID);
		$message = stripslashes(strip_tags($post_data['Content']));
		$subject = stripslashes($post_data['Title']);
	
		// add headers
		$headers .= "From: $mail_from\r\n";
	
		// send the mail!
		mail($mail_to, $subject, $message, $headers);
	}

    return $post_ID;
}

function e5p_mailto() {
	echo '<div id="postexcerpt" class="postbox if-js-open" ><div class="handlediv" title="Click to toggle"><br /></div><h3 class="hndle"><span>Email 5 People</span></h3><div class="inside"><input type="hidden" name="metakeyinput" value="Email_To" /><textarea id="metavalue" name="metavalue" rows="2" cols="25" tabindex="10"></textarea><p>Enter 5 email addresses (each on their own line) to send this post.</p>'; 

}

add_action('publish_post', 'email_5_people');
add_action('edit_form_advanced', 'e5p_mailto');

?>
