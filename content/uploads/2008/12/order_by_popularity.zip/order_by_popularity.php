<?php

/*
Plugin Name: Order by Popularity
Plugin URI: http://sexysexypenguins.com/wp-content/uploads/2008/12/order_by_popularity.zip
Description: Order posts by popularity, Alex Kings <a href="http://wordpress.org/extend/plugins/popularity-contest/">Popularity Contest</a> plugin required.
Version: 0.1
Author: Clint Savage <herlo1@gmail.com>
Author URI: http://sexysexypenguins.com
*/


function obp_orderby( $orderby ) {
	global $wpdb; 

	if (function_exists('akpc_view')) {
		return $wpdb->ak_popularity . ".total DESC";
//		return "post_name DESC";
	}
	return $orderby;

}

function obp_join( $join ) {
	global $wpdb; 

	if (function_exists('akpc_view')) {
		$join .= " LEFT JOIN " . $wpdb->ak_popularity . " ON " . $wpdb->posts . ".ID = " . $wpdb->ak_popularity .  ".post_id";
	}
	return $join;
}


add_filter('posts_orderby', 'obp_orderby');
add_filter('posts_join', 'obp_join' );

?>
